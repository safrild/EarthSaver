export interface Group {
  id: string;
  name: string;
  description: string;
  posts: any[];
  users: any[];
}
