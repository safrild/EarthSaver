export interface Profile {
  id: string;
  bio: string;
  age: number;
  hobbies: string;
  posts: any[];
  groups: any[];
}
