export interface Post {
  username: string;
  text: string;
}
