export interface PostData {
  username: string;
  text: string;
}
