export interface AuthData {
  email: string;
  password: string;
  // hometown: string;
}
// az authentikaciohoz szukseges adatok
