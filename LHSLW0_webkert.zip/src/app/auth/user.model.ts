export interface User {
  email: string;
  password: string;
  hometown: string;
}
// minden, ami a User tablaban lesz
